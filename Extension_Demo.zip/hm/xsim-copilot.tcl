namespace eval ::ExtensionDemoHM {}
proc ::ExtensionDemoHM::XSimCopilot { } {
    # 你的逻辑在这里
    tk_messageBox -title "XSim Copilot" -message "working"
}