# Init script called when an extension is loaded
# Used to run onetime initialization of extension specific functionality.

namespace eval ::ExtensionDemoHM {
	variable scriptdir  [file dirname [info script]]
}

proc ::ExtensionDemoHM::Solids2Comps { } {

	*createentitypanel comps 1 "Select component with multiple solids"
	set compId [ hm_info lastselectedentity comps ]
	*createmark solids 1 "by comp id" $compId
	set solidList [ hm_getmark solids 1 ]
	*clearmark solids 1

	::ExtensionDemoHM::Graphics 0
	
	foreach solidId $solidList {
		*createentity comps name="component_$solidId"
		*createmark solids 1 $solidId
		*movemark solids 1 "component_$solidId"
		*clearmark solids 1
	}

	::ExtensionDemoHM::Graphics 1
}

proc ::ExtensionDemoHM::Graphics { switch } {

	if { $switch == 0 } {
		*setoption block_redraw=1
		*setoption block_messages=1
		*setoption block_error_messages=1
		*setoption command_file_state=0
		hm_blockbrowserupdate 1
	} else {
		*setoption block_redraw=0
		*setoption block_messages=0
		*setoption block_error_messages=0
		*setoption command_file_state=1
		hm_blockbrowserupdate 0
	}
}

proc ::ExtensionDemoHM::ToClipboardHM { } {

	foreach {x y w h} [hm_getgraphicsarea] {}
	hm_windowtoclipboard $x $y $w $h

}

proc ::ExtensionDemoHM::ToFileHM { } {

	set filename [ tk_getSaveFile -title "Save Screenshot" ]
	foreach {x y w h} [hm_getgraphicsarea] {}
	hm_windowtofile $x $y $w $h $filename
}

source [file join $::ExtensionDemoHM::scriptdir "xsim-copilot.tcl"]