# Init script called when an addon is loaded
# Used to run onetime initialization of addon specific functionality.

# Source all *.tcl file in the same directory in the given namespace

package require postquery
namespace eval ::ExtensionDemoGlobal {
	global env
	variable workDir [file normalize [[::hwp::GetSession] GetSystemVariable CURRENTWORKINGDIR]]
}

proc ::ExtensionDemoGlobal::myDialog {w title text image default args} {
	toplevel $w
	wm title $w $title
	pack [label $w.l -text $text] -pady 20
	pack [frame $w.f] -pady 10 -padx 20
	set n 0
	foreach b $args {
		set cmd [format {set ::sel %s; destroy %s} $n $w]
		button $w.f.$n -text $b -command $cmd
		grid $w.f.$n -row 0 -column $n -padx 20
		incr n
	}
	vwait ::sel
	return $::sel
}

proc ::ExtensionDemoGlobal::CaptureToPNGFile {} {
    variable workDir
	set types {
		{{PNG Files}       {.png}        }
	}
	set imageFile "screenshot.png"
	set imageFileWithPath [ tk_getSaveFile -title "Save Screenshot" -initialdir $workDir -initialfile $imageFile -filetypes $types]
	[::hwp::GetSession] CaptureScreen PNG "$imageFileWithPath" 
	if {[file exists $imageFileWithPath]} {
		myDialog .dummy "Image Active Window" "PNG of graphics area successfully saved in :\n\n${imageFileWithPath}" {} 0 {OK}
	}
}

proc ::ExtensionDemoGlobal::CaptureToClipboard {} {
	[::hwp::GetSession] CaptureScreen CLIPBOARD dummyFileName.png 
	tk_messageBox -message "Screenshot successfully saved in Clipboard!" -type ok
}

proc ::ExtensionDemoGlobal::convertToFileName {text} {
	set text [string map -nocase { ( "" ) "" : "" \\ _ / _ ~ "" ä ae ö oe ü ue \" "" \' "" # "" * "" \´ "" \` "" " " _ ß ss ? "" @ _at_ ; _ , _} $text]
	set text [regsub -all {[^a-zA-Z0-9_\s]} $text ""]
	set text [regsub -all {[_]+} $text _]
	return $text
}
