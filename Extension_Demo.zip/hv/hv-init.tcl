# Init script called when an addon is loaded
# Used to run onetime initialization of addon specific functionality.

namespace eval ::ExtensionDemoHV {
	variable fileVar [info script]
	variable dirVar [file dirname $fileVar]
}

proc ::ExtensionDemoHV::loadHVAnimationDemoSession {} {
	variable dirVar
	hwc open session [file normalize [file join $dirVar HV_Animate_Demo_Session.mvw]] replace
}

proc ::ExtensionDemoHV::CaptureHVWindowToJPEGFileFixedNamResolution { } {
	set imageWidth 3200
	set imageHeight 1800
	set type PNG
	set t [expr rand()][clock milliseconds]
	hwi GetSessionHandle sesh$t
	set exportDir [sesh$t GetSystemVariable CURRENTWORKINGDIR]
	hwi GetActiveClientHandle client$t
	client$t GetModelHandle model$t [client$t GetActiveModel]
	set modelLabel [model$t GetLabel]
	set filePath [file join $exportDir "${modelLabel}.${type}"]
	set rootDir $exportDir
	set fileNum 1
	set digitExtension "_[format %03i $fileNum]"
	set fileExtension [file extension $filePath]
	set fileName [file tail [file root $filePath]]
	set fileName [::ExtensionDemoGlobal::convertToFileName $fileName]
	set dirName [file tail $filePath]
	set tmpFile [file join $rootDir "${fileName}${digitExtension}${fileExtension}"]
	while {[file exists $tmpFile] && $fileNum < 100} {
		incr fileNum
		set digitExtension "_[format %03i $fileNum]"
		set tmpFile [file join $rootDir "${fileName}${digitExtension}${fileExtension}"]
	}
	set imageFileWithPath [file normalize $tmpFile]
	sesh$t CaptureActiveWindow ${type} "$imageFileWithPath" pixels $imageWidth $imageHeight
	sesh$t ReleaseHandle
	if {[file exists $imageFileWithPath]} {
		::ExtensionDemoGlobal::myDialog .dummy "Image Active Window" "PNG of active window successfully saved in :\n\n${imageFileWithPath}" {} 0 {OK}
	}
}

# Animate active page animations one time

proc ::ExtensionDemoHV::animateAnimtaionWindowsActivePageOnce {} {
	hwi OpenStack
	set ui [expr rand()][clock seconds]
	hwi GetSessionHandle ses_$ui
	ses_$ui GetProjectHandle pro_$ui
	pro_$ui GetPageHandle page_$ui [pro_$ui GetActivePage]
	if {[page_$ui GetAnimationMode] == "transient"} {
		set numWindows [page_$ui GetNumberOfWindows]
		set counter 0
		for {set j 1} {$j <= $numWindows} {incr j} {
			page_$ui GetWindowHandle win_$ui $j
			if {[win_$ui GetClientType] == "Animation"} {
				incr counter
				page_$ui GetAnimatorHandle animator_$ui
				win_$ui GetClientHandle client_$ui
				set incrNumber 0
				set currentTime [animator_$ui GetCurrentTime]
				set currentStep [animator_$ui GetCurrentStep]
				animator_$ui SetCurrentStep 0
				client_$ui Draw
				animator_$ui SetCurrentTime [animator_$ui GetStartTime]
				while { $incrNumber < 1 } {
					while { [animator_$ui GetCurrentTime] < [animator_$ui GetEndTime] } {
						animator_$ui Next
						client_$ui Draw
					}
					incr incrNumber
				}
				animator_$ui SetCurrentTime $currentTime
				animator_$ui SetCurrentStep $currentStep
				animator_$ui ReleaseHandle
				client_$ui ReleaseHandle
			}
			win_$ui ReleaseHandle
		}
		page_$ui Draw
	}
	hwi CloseStack
}

# Animate all pages containing an Animation one time

proc ::ExtensionDemoHV::animateAllAnimtaionWindowsOnce {} {
	hwi OpenStack
	set ui [expr rand()][clock seconds]
	hwi GetSessionHandle ses_$ui
		ses_$ui GetProjectHandle pro_$ui
		set activePageNum [pro_$ui GetActivePage]
			pro_$ui GetPageHandle activePage_$ui $activePageNum
			set activeWinNum [activePage_$ui GetActiveWindow]
				activePage_$ui ReleaseHandle
				set numPages [pro_$ui GetNumberOfPages]
				for {set i 1} {$i <= $numPages} {incr i} {
					pro_$ui GetPageHandle page_$ui $i
					if {[page_$ui GetAnimationMode] == "transient"} {
						pro_$ui SetActivePage $i
						page_$ui Draw
						set numWindows [page_$ui GetNumberOfWindows]
						set counter 0
						for {set j 1} {$j <= $numWindows} {incr j} {
							page_$ui GetWindowHandle win_$ui $j
							if {[win_$ui GetClientType] == "Animation"} {
								incr counter
								page_$ui GetAnimatorHandle animator_$ui
								win_$ui GetClientHandle client_$ui
								set incrNumber 0
								set currentTime [animator_$ui GetCurrentTime]
								set currentStep [animator_$ui GetCurrentStep]
								animator_$ui SetCurrentStep 0
								client_$ui Draw
								animator_$ui SetCurrentTime [animator_$ui GetStartTime]
								while { $incrNumber < 1 } {
									while { [animator_$ui GetCurrentTime] < [animator_$ui GetEndTime] } {
										animator_$ui Next
										client_$ui Draw
									}
									incr incrNumber
								}
								animator_$ui SetCurrentTime $currentTime
								animator_$ui SetCurrentStep $currentStep
								animator_$ui ReleaseHandle
								client_$ui ReleaseHandle
							}
							win_$ui ReleaseHandle
						}
					}
					page_$ui ReleaseHandle
				}
			pro_$ui SetActivePage $activePageNum
			pro_$ui GetPageHandle activePage_$ui $activePageNum
			activePage_$ui SetActiveWindow $activeWinNum
	hwi CloseStack
}

proc ::ExtensionDemoHV::myHVTool1 {} {
	variable fileVar
	set procName [dict get [info frame 0] proc]
	tk_messageBox -title "HV Custom Tool 1" -type ok -message "Edit Me!\n\n I am proc \n\n$procName \n\nlocated in \n\n$fileVar"
}