# Init script called when an addon is loaded
# Used to run onetime initialization of addon specific functionality.

namespace eval ::ExtensionDemoHG {
	variable fileVar [info script]
	variable dirVar [file dirname $fileVar]
}

proc ::ExtensionDemoHG::loadHGFitDemoSession {} {
	variable dirVar
	hwc open session [file normalize [file join $dirVar HG_Fit_Demo_Session.mvw]] replace
}


proc ::ExtensionDemoHG::CaptureHGWindowToJPEGFileFixedNamResolution { } {
	set imageWidth 3200
	set imageHeight 1800
	set type PNG
	set t [expr rand()][clock milliseconds]
	hwi GetSessionHandle sesh$t
	set exportDir [sesh$t GetSystemVariable CURRENTWORKINGDIR]
	hwi GetActiveClientHandle client$t
	client$t GetHeaderHandle header$t
	set plotHeader [header$t GetExpandedText]
	set plotHeader [::ExtensionDemoGlobal::convertToFileName $plotHeader]
	set filePath [file join $exportDir "${plotHeader}.${type}"]
	set rootDir $exportDir
	set fileNum 1
	set digitExtension "_[format %03i $fileNum]"
	set fileExtension [file extension $filePath]
	set fileName [file tail [file root $filePath]]
	set dirName [file tail $filePath]
	set tmpFile [file join $rootDir "${fileName}${digitExtension}${fileExtension}"]
	while {[file exists $tmpFile] && $fileNum < 100} {
		incr fileNum
		set digitExtension "_[format %03i $fileNum]"
		set tmpFile [file join $rootDir "${fileName}${digitExtension}${fileExtension}"]
	}
	set imageFileWithPath [file normalize $tmpFile]
	sesh$t CaptureActiveWindow ${type} "$imageFileWithPath" pixels $imageWidth $imageHeight
	sesh$t ReleaseHandle
	if {[file exists $imageFileWithPath]} {
		::ExtensionDemoGlobal::myDialog .dummy "Image Active Window" "PNG of active window successfully saved in :\n\n${imageFileWithPath}" {} 0 {OK}
	}
}

proc ::ExtensionDemoHG::autoFitAllPlots {{mode all}} {
	set ui [expr rand()][clock seconds]
	hwi OpenStack
	hwi GetSessionHandle ses$ui
	set projectHandle [ses$ui GetProjectHandle pro$ui]
	set activePageHandle [$projectHandle GetPageHandle activePage$ui [$projectHandle GetActivePage]]
	set numpages [$projectHandle GetNumberOfPages]
	for {set i 1} {$i <= $numpages} {incr i} {
		set pageHandle [$projectHandle GetPageHandle page$ui $i]
		set numwin [$pageHandle GetNumberOfWindows]
		for {set j 1} {$j <= $numwin} {incr j} {
			set windowHandle [$pageHandle GetWindowHandle window$ui $j]
			set clienttype [$windowHandle GetClientType]
			if {$clienttype == "Plot"} {
				set clientHandle [$windowHandle GetClientHandle client$ui]
				$clientHandle Recalculate
				if {$mode == "all"} {
					$clientHandle Autoscale true true
				} elseif {$mode == "x"} {
					$clientHandle Autoscale true false
				} elseif {$mode == "y"} {
					$clientHandle Autoscale false true
				}
				$clientHandle ReleaseHandle
			}
			$windowHandle ReleaseHandle 
		}
		$pageHandle ReleaseHandle
	}
	$activePageHandle Draw
	$activePageHandle ReleaseHandle
	hwi CloseStack
}

proc ::ExtensionDemoHG::myHGTool1 {} {
	variable fileVar
	set procName [dict get [info frame 0] proc]
	tk_messageBox -title "HG Custom Tool 1" -type ok -message "Edit Me!\n\n I am proc \n\n$procName \n\nlocated in \n\n$fileVar"
}


